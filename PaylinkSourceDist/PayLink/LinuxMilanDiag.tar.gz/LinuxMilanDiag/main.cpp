/*--------------------------------------------------------------------------*\
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
\*--------------------------------------------------------------------------*/
 
/*--------------------------------------------------------------------------*\
 * System Includes.
\*--------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>

/*--------------------------------------------------------------------------*\
 * GTK Includes.
\*--------------------------------------------------------------------------*/
#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <gtk/gtk.h>
#include <gnome.h>

/*--------------------------------------------------------------------------*\
 * Application Includes.
\*--------------------------------------------------------------------------*/
#include "interface.h"
#include "support.h"
#include "data_funcs.h"

/*--------------------------------------------------------------------------*\
 * Global Variables.
\*--------------------------------------------------------------------------*/
GtkWidget     *WinMain        = NULL;
GtkWidget     *WinComment     = NULL;
GtkWidget     *WinSave        = NULL;
GtkWidget     *NoteMain       = NULL;
GtkTextBuffer *DiagBuffer     = NULL;
GtkTextBuffer *SysBuffer      = NULL;
GtkTextBuffer *PerpBuffer     = NULL;
GtkWidget     *DiagView       = NULL;
GtkWidget     *SysView        = NULL;
GtkWidget     *PerpView       = NULL;
gint           MainTimerTag   = -1;
gint           PerpTimerTag   = -1;

/*--------------------------------------------------------------------------*\
 * :
 * -------------
 *
 *
 * Arguments:
 * ----------
 *
 * Return:
 * -------
 *
\*--------------------------------------------------------------------------*/
int
main (int argc, char *argv[])
{
  PangoFontDescription *font_desc;
  
  /*-- Initialise Gnome Library --------------------------------------*/
  gnome_program_init ("MilanDiag", "1.01", LIBGNOMEUI_MODULE,
                      argc, argv,
                      GNOME_PARAM_APP_DATADIR, "/usr/bin/",
                      NULL);

  /*-- Create our main application window -----------------------------*/
  WinMain = create_win_main ();
  
  /*-- Create comment window ------------------------------------------*/
  WinComment = create_win_comment ();
  
  /*-- Create save window ---------------------------------------------*/
  WinSave = create_file_choose_save ();
  
  /*-- Set window positions / icons ----------------------------------*/
  gtk_window_set_position       (GTK_WINDOW(WinMain),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_window_set_icon_from_file (GTK_WINDOW(WinMain), 
                                 "MilanDiag-icon.png", NULL);
  gtk_window_set_position       (GTK_WINDOW(WinComment),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_window_set_icon_from_file (GTK_WINDOW(WinComment), 
                                 "MilanDiag-icon.png", NULL);
  gtk_window_set_position       (GTK_WINDOW(WinSave),GTK_WIN_POS_CENTER_ALWAYS);
  gtk_window_set_icon_from_file (GTK_WINDOW(WinSave), 
                                 "MilanDiag-icon.png", NULL);
                                 
  /*-- Create our text buffers ----------------------------------------*/
  DiagBuffer = gtk_text_buffer_new (NULL);
  SysBuffer  = gtk_text_buffer_new (NULL);
  PerpBuffer = gtk_text_buffer_new (NULL);
  
  /*-- Assign our buffers to the correct text views -------------------*/
  DiagView = lookup_widget(GTK_WIDGET(WinMain), "txt_diag_tab");
  if ((font_desc = pango_font_description_from_string ("monospace 8")))
    gtk_widget_modify_font (DiagView, font_desc);
  SysView  = lookup_widget(GTK_WIDGET(WinMain), "txt_sysinfo_tab");
  if ((font_desc = pango_font_description_from_string ("monospace 8")))
    gtk_widget_modify_font (SysView, font_desc);
  PerpView = lookup_widget(GTK_WIDGET(WinMain), "txt_peripherals_tab");
  if ((font_desc = pango_font_description_from_string ("monospace 8")))
    gtk_widget_modify_font (PerpView, font_desc);
  gtk_text_view_set_buffer (GTK_TEXT_VIEW(DiagView), DiagBuffer);
  gtk_text_view_set_buffer (GTK_TEXT_VIEW(SysView),  SysBuffer);
  gtk_text_view_set_buffer (GTK_TEXT_VIEW(PerpView), PerpBuffer);
  
  /*-- Show the main application window -------------------------------*/
  gtk_widget_show (WinMain);
  
  /*-- Set notbook reference ------------------------------------------*/
  NoteMain = lookup_widget(GTK_WIDGET(WinMain), "notebook1");
  
  /*-- Start the main timer ticking away ------------------------------*/
  MainTimerTag = g_timeout_add ( (guint) 500, DataFn_MainUpdater, NULL );
  
  /*-- Start the main gtk event processing loop -----------------------*/
  gtk_main ();
  return 0;
}
