/*--------------------------------------------------------------------------*\
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
\*--------------------------------------------------------------------------*/
 
/*--------------------------------------------------------------------------*\
 * System Includes.
\*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*\
 * GTK Includes.
\*--------------------------------------------------------------------------*/
#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <gnome.h>

/*--------------------------------------------------------------------------*\
 * Application Includes.
\*--------------------------------------------------------------------------*/
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "data_funcs.h"

/*--------------------------------------------------------------------------*\
 * Externel Variables.
\*--------------------------------------------------------------------------*/
extern GtkWidget *WinMain;
extern GtkWidget *WinComment;
extern GtkWidget *WinSave;

/*--------------------------------------------------------------------------*\
 * Private Global Variables.
\*--------------------------------------------------------------------------*/
static int Ctrl  = FALSE;
static int Alt   = FALSE;
static int Shift = FALSE;

/*****************************************************************************\
 *****************************************************************************
                      Pause button callback functions.
 *****************************************************************************
\*****************************************************************************/ 
/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_pause_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{ DataFn_PauseResume(togglebutton);
}

/*****************************************************************************\
 *****************************************************************************
                       Mail button callback functions.
 *****************************************************************************
\*****************************************************************************/ 
/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_mail_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{ DataFn_SendEmail();
}

/*****************************************************************************\
 *****************************************************************************
                      Comment button callback functions.
 *****************************************************************************
\*****************************************************************************/ 
/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_comment_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{ 
  GtkWidget *txt_comment = lookup_widget(GTK_WIDGET(WinComment), "txt_comment");
  
  /*-- Clear the data within the comment entry box -------------------*/
  gtk_entry_set_text (GTK_ENTRY(txt_comment), "");
  
  /*-- Set the text box to have focus --------------------------------*/
  gtk_widget_grab_focus (txt_comment);
  gtk_widget_show (WinComment);	
}

/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_comment_ok_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *txt_comment = lookup_widget(GTK_WIDGET(WinComment), "txt_comment");
  gchar     *comment     = (gchar*)gtk_entry_get_text(GTK_ENTRY(txt_comment));

  if (*comment)
    DataFn_AddComment (comment);
  gtk_widget_hide (WinComment);	  
}

/*****************************************************************************\
 *****************************************************************************
                       Clear button callback functions.
 *****************************************************************************
\*****************************************************************************/ 
/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_clear_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{ DataFn_ClearDiagData();
}

/*****************************************************************************\
 *****************************************************************************
                     Copy All button callback functions.
 *****************************************************************************
\*****************************************************************************/ 
/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_copy_all_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{ DataFn_CopyAll();
}

/*****************************************************************************\
 *****************************************************************************
                       Save button callback functions.
 *****************************************************************************
\*****************************************************************************/ 
/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_save_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{ 
  GtkWidget *save_win = lookup_widget(GTK_WIDGET(WinSave), "file_choose_save");
  
  gtk_file_chooser_set_filename (GTK_FILE_CHOOSER(save_win),     "/root/Mimhei.log");
  gtk_file_chooser_set_current_name (GTK_FILE_CHOOSER(save_win), "/root/Mimhei.log");
  gtk_widget_show (WinSave);	
}

/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_save_cancel_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{ gtk_widget_hide (WinSave);
}

/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_save_save_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
  gchar     *filename = NULL;
  GtkWidget *save_win = lookup_widget(GTK_WIDGET(WinSave), "file_choose_save");
  
  filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER(save_win));
  if (*filename)
  { DataFn_Save(filename);
    gtk_widget_hide (WinSave); 
  }
}

/*****************************************************************************\
 *****************************************************************************
                      Print button callback functions.
 *****************************************************************************
\*****************************************************************************/ 
/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_print_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{ DataFn_Print();
}

/*****************************************************************************\
 *****************************************************************************
                      Notebook (tab) callback functions.
 *****************************************************************************
\*****************************************************************************/ 
/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_notebook1_switch_page               (GtkNotebook     *notebook,
                                        GtkNotebookPage *page,
                                        guint            page_num,
                                        gpointer         user_data)
{ return;
}

/*****************************************************************************\
 *****************************************************************************
                      Command Entry callback functions.
 *****************************************************************************
\*****************************************************************************/ 
/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_txt_cmd_entry_activate              (GtkEntry        *entry,
                                        gpointer         user_data)
{ 
  gchar *cmd = (gchar*)gtk_entry_get_text(GTK_ENTRY(entry));

  /*-- Send the command to the PayLink device -------------------------*/
  if (*cmd) DataFn_SendCommand (cmd);
  
  /*-- Clear the contents of the text entry widget --------------------*/
  gtk_entry_set_text (GTK_ENTRY(entry), "");
}

/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
gboolean
on_win_main_button_press_event         (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data)
{
  GtkWidget   *txt_cmd_entry = lookup_widget(GTK_WIDGET(WinMain), "txt_cmd_entry");
  static int ToggleState = TRUE;

  if ((event->button == 3) && Ctrl && Alt && Shift)
  { if (ToggleState == TRUE)
    { /*-- Change toggle state ----------------------------------------*/
      ToggleState = FALSE;
  
      /*-- Enable the command entry point -----------------------------*/
      gtk_widget_set_sensitive (GTK_WIDGET(txt_cmd_entry), TRUE);

    }else
    { /*-- Change toggle state ----------------------------------------*/
      ToggleState = TRUE;
  
      /*-- Disable the command entry point ----------------------------*/
      gtk_widget_set_sensitive (GTK_WIDGET(txt_cmd_entry), FALSE);
    }
  }
  return FALSE;
}

/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
gboolean
on_key_press_event                     (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data)
{
  switch (event->keyval)
  { case GDK_Shift_L:   Shift = TRUE; break;
    case GDK_Control_L: Ctrl  = TRUE; break;
    case GDK_Alt_L:     Alt   = TRUE; break;
  }
  return FALSE;
}

/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
gboolean
on_key_release_event                   (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data)
{
  switch (event->keyval)
  { case GDK_Shift_L:   Shift = FALSE; break;
    case GDK_Control_L: Ctrl  = FALSE; break;
    case GDK_Alt_L:     Alt   = FALSE; break;
  }
  return FALSE;
}


/*****************************************************************************\
 *****************************************************************************
                      Version button callback functions.
 *****************************************************************************
\*****************************************************************************/ 
/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_version_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{ DataFn_Version();
}

/*****************************************************************************\
 *****************************************************************************
                       Reset button callback functions.
 *****************************************************************************
\*****************************************************************************/ 
/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
on_btn_reset_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{ DataFn_Reset();
}
