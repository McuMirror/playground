/*--------------------------------------------------------------------------*\
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
\*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*\
 * System Includes.
\*--------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/*--------------------------------------------------------------------------*\
 * AES Includes.
\*--------------------------------------------------------------------------*/
#define __HAVE_PRINTTEXT__
#include "../../Aesimhei.h"
#include "../AccessDLL/MapRam.h"
#include "../AccessDLL/PCAccess.cpp"
//#include "CheckAccess.h"

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
#define __stdcall
#ifndef MSG
#define MSG(a,b,c,d)  if (Messages)                 \
                        {                           \
                        printf("%s: %s\r\n", b, c); \
                        return 0 ;                  \
                        }
#endif

/*--------------------------------------------------------------------------*\
 * GTK Includes.
\*--------------------------------------------------------------------------*/
#include <gtk/gtk.h>
#include <gnome.h>

/*--------------------------------------------------------------------------*\
 * Application Includes.
\*--------------------------------------------------------------------------*/
#include "interface.h"
#include "support.h"
#include "data_funcs.h"

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void (*PrintText) (char*) = PrintTextHook;

/*--------------------------------------------------------------------------*\
 * External Variables.
\*--------------------------------------------------------------------------*/
extern GtkWidget      *WinMain;
extern GtkWidget      *NoteMain;
extern GtkTextBuffer  *DiagBuffer;
extern GtkTextBuffer  *SysBuffer;
extern GtkTextBuffer  *PerpBuffer;
extern GtkWidget      *DiagView;
extern GtkWidget      *SysView;
extern GtkWidget      *PerpView;
extern gint            MainTimerTag;
extern gint            PerpTimerTag;

/*--------------------------------------------------------------------------*\
 * Private Global Variables.
\*--------------------------------------------------------------------------*/
static long                 PCPresentFlag    = 0;
static int                  LineIndex        = 0;
static char                 DiagnosticsFrozen= FALSE;
static char                 Going            = FALSE;
static char                 Restarting       = FALSE;
static int                  StageMask        = 0;
static unsigned volatile long *StageIndexPtr = NULL;
static char                *StageBuffer      = NULL;
static DiagOutputBlock     *DiagOutputArea   = NULL;
static GtkTextBuffer       *PauseBuffer      = NULL;

typedef struct
{ long Code;
  long Length;
  char Data[128];
}BLOCK;
BLOCK Block;

/*--------------------------------------------------------------------------*\
 * DataFn_CheckAccess:
 * -------------------
\*--------------------------------------------------------------------------*/
int
DataFn_CheckAccess                       (int             Messages,
                                         int             TestRam)
{
    int         CardOK = 1 ;
    char        Message[1024] ;
    long        MajorVersion ;
    float       MinorVersion ;
    int         fd ;

    if (PrintText == NULL)
        PrintText = PrintTextHook;

    sprintf(Message,"AES Intelligent Money Handling Equipment Interface\n") ;
    if (PrintText) PrintText(Message) ;

    /*-- Determine Operating Version (kernel version) -----------------*/
    if ((fd = open ("/proc/version", O_RDONLY)) != -1)
    {
        size_t      len             =  0;
        char       *p               =  NULL;
        char        buff   [200]    =  "";
        char        status[1024]    =  "";
        int         x               =  0;

        /*-- Read data from the file ----------------------------------*/
        len = read (fd, status, sizeof(status));
        close (fd);

        /*-- Null terminate the data ----------------------------------*/
        status[len] = 0;

        /*-- Parse the data -------------------------------------------*/
        for (p=status, x=0; *p && x<2; p++)
            if (*p == ' ') x++;
        for (x=0; *p && (*p!='.'); p++)
            buff[x++] = *p;
        buff[x] = 0;
        MajorVersion = atol(buff);

        for (x=0; *p && *p=='.'; p++);
        for (x=0; *p && (*p!='-'); p++)
            buff[x++] = *p;
        buff[x] = 0;
        MinorVersion = strtof(buff, NULL);
        sprintf  (Message,"OS Version %ld.%f\n", MajorVersion, MinorVersion) ;
        if (PrintText) PrintText(Message) ;
    }

    /*-- Check the Driver Files ---------------------------------------*/
    {
        struct stat buf ;
        int         notFound = 0 ;

        sprintf(Message,"Checking Driver File:\n") ;
        if (PrintText) PrintText(Message) ;
        if (stat("/usr/bin/AESWDriver",         &buf) != -1)
        {   sprintf(Message,"    Found at: %s\n", "/usr/bin/AESWDriver") ;
            if (PrintText) PrintText(Message) ;
            sprintf(Message, "        Timestamp : %s", ctime( &buf.st_mtime )) ;
            if (PrintText) PrintText(Message) ;
        }else
        {   sprintf(Message,"    Not Found (<%s> checked)\n", "/usr/bin/AESWDriver") ;
            if (PrintText) PrintText(Message) ;
            notFound = 1 ;
        }

        sprintf(Message,"\nChecking Library Files:\n") ;
        if (PrintText) PrintText(Message) ;
        if (stat("/usr/lib/libftdi.so",       &buf) != -1)
        {   sprintf(Message,"    Found at: %s\n", "/usr/lib/libftdi.so") ;
            if (PrintText) PrintText(Message) ;
            sprintf(Message, "        Timestamp : %s", ctime( &buf.st_mtime )) ;
            if (PrintText) PrintText(Message) ;
        }else
        {   sprintf(Message,"    Not Found (<%s> checked)\n", "/usr/lib/libftd2xx.so") ;
            if (PrintText) PrintText(Message) ;
            notFound = 1 ;
        }
        if (stat("/usr/lib/libaes_access.so",   &buf) != -1)
        {   sprintf(Message,"    Found at: %s\n", "/usr/lib/libaes_access.so") ;
            if (PrintText) PrintText(Message) ;
            sprintf(Message, "        Timestamp : %s", ctime( &buf.st_mtime )) ;
            if (PrintText) PrintText(Message) ;
        }else
        {   sprintf(Message,"    Not Found (<%s> checked)\n", "/usr/lib/libaes_access.so") ;
            if (PrintText) PrintText(Message) ;
            notFound = 1 ;
        }
    }

    /*-- Check out raw access to device -------------------------------*/
    {
        enum { MEMORY_SIZE =   4096 } ;
        unsigned int               i ;
        unsigned int               Top ;
        volatile unsigned short *  PCIMemory ;
        unsigned int               Value ;
        static unsigned short      Saved[MEMORY_SIZE] ;

        if (MapDPRam() != ApiSuccess)
        {   if (SharedMemoryBase)
            {   if (MMFile)
                {   sprintf(Message,"\nNo contact between Genoa driver and firmware on unit\n") ;
                    if (PrintText) PrintText(Message) ;
                }else
                {   sprintf(Message,"\nMilan firmware not running on unit\n") ;
                    if (PrintText) PrintText(Message) ;
                }
                MSG(NULL, " No contact with firmware on unit   ", "AESIMHEI Error", MB_OK) ;
            }else
            {   sprintf(Message,"\nNo interface found to Milan / Genoa unit\n") ;
                if (PrintText) PrintText(Message) ;
                MSG(NULL, " No interface found to unit   ", "AESIMHEI Error", MB_OK) ;
            }
            CardOK = 0 ;
        }else
        {   if (MMFile)
            {   TestRam = 0 ;      /*-- Don't test PC shared memory! --*/
                sprintf(Message,"\nDetails on AES Genoa USB Interface Unit\n") ;
                if (PrintText) PrintText(Message) ;
            }else
            {   sprintf(Message,"\nDetails on AES Milan PCI Interface Unit\n") ;
                if (PrintText) PrintText(Message) ;
            }

            switch(BasicControl->MeaningVersion)
            {
                case 0:
                    sprintf(Message,"    AES Factory Self Test: Version %lx\n",
                                         BasicControl->CodeVersion) ;
                    if (PrintText) PrintText(Message) ;
                    break ;

                default:
                    sprintf(Message,"    Unknown AES application (%lx)\n",
                                          BasicControl->MeaningVersion) ;
                    if (PrintText) PrintText(Message);
                    CardOK = 0 ;
                    break ;
            }

            if (BasicControl->CardSelfTest != SELFTEST_OK)
            {
                sprintf(Message,"    *** Unit self test failure - code %04lx ***\n",
                                     BasicControl->CardSelfTest) ;
                if (PrintText) PrintText(Message) ;

                if (Messages)
                {   /*-- Special case to carry on ---------------------*/
                    MSG(NULL, "  Unit self test failure  ", "AESIMHEI Error", MB_OK) ;
                }
            }

            if (BasicControl->OutputPointer  < sizeof *BasicControl ||
                BasicControl->InputPointer   < sizeof *BasicControl ||
                BasicControl->DiagOutPointer < sizeof *BasicControl ||
                BasicControl->OutputPointer  > 8192 ||
                BasicControl->InputPointer   > 8192 ||
                BasicControl->DiagOutPointer > 8192)
            {
                sprintf(Message,"    *** Internals corrupt ***\n") ;
                if (PrintText) PrintText(Message) ;

                MSG(NULL, "  Internals corrupt  ",
                                    "AESIMHEI Error", MB_OK) ;
                return 0 ;
            }

            /*-- Now do RAM self test ---------------------------------*/
                        if (TestRam)
            {
                unsigned OutputOffset = BasicControl->OutputPointer ;
                PCIMemory = (unsigned short *)BasicControl ;

                memcpy(Saved, (void *) PCIMemory, sizeof Saved) ;
                for (Top = 0 ; Top < 0xffff ; Top += MEMORY_SIZE)
                {
                    for (i = 0 ; i < MEMORY_SIZE ; ++i)
                        PCIMemory[i] = Top + i ;

                    for (i = 0 ; i < MEMORY_SIZE ; ++i)
                    {
                        Value = PCIMemory[i] ;

                        /*-- Special case failure ---------------------*/
                        if ((Value != Top + i) &&
                            OutputOffset <= i * 2 &&
                            i * 2 <= OutputOffset + sizeof(OutputAreaBlock))
                        {
                            /*-- Area that the H8 is accessing --------*/
                            int Retries = 0 ;
                            do
                            {
                                PCIMemory[i] = Top + i ;
                                Value = PCIMemory[i] ;
                                ++Retries ;
                            } while ((Value != Top + i) && Retries < 1000000) ;

                            if (Retries > 10)
                            {   sprintf(Message,"        Took %d goes to write %x\n", Retries, Value) ;
                                if (PrintText) PrintText(Message) ;
                            }
                        }

                        if (Value != Top + i)
                        {   sprintf(Message,"    *** Memory Fault at %x, wrote %x, read %x\n",
                                                 i, Top + i, Value) ;
                            if (PrintText) PrintText(Message) ;

                            if (CardOK)
                            {   MSG(NULL, " Dual Port RAM failure ",
                                                "AESIMHEI Error", MB_OK) ;
                            }
                            CardOK = 0 ;
                        }
                    }
                }

                /*-- Allow for H8 read problem. -----------------------*/
                do
                {   memcpy((void *)PCIMemory, Saved, sizeof Saved) ;
                } while (CardOK && memcmp((void *)PCIMemory, Saved, sizeof Saved)) ;
            }
        }

        if (CardOK)
        {   sprintf  (Message,"        Device Checked - OK\n") ;
            if (PrintText) PrintText(Message) ;
        }

        if (!CardOK)
            return 0 ;
    }

    if (CardOK)
    {
        char *ReleaseType ;

        switch(BasicControl->CodeVersion >> 24)
        { case 0: ReleaseType = "Special" ;     break ;
          case 1: ReleaseType = (char*)"Development" ; break ;
          case 2: ReleaseType = (char*)"Alpha Test" ;  break ;
          case 3: ReleaseType = (char*)"Beta Test" ;   break ;
          case 4: ReleaseType = (char*)"Full" ;        break ;
          default:ReleaseType = (char*)"Unknown" ;     break ;
        }

        sprintf(Message,"\nFirmware Release Type: %s\n", ReleaseType) ;
        if (PrintText) PrintText(Message) ;
        sprintf(Message,    "Firmware Code Version: %ld.%ld.%ld\n\n",
                            (BasicControl->CodeVersion >> 16) & 0xff,
                            (BasicControl->CodeVersion >>  8) & 0xff,
                            (BasicControl->CodeVersion      ) & 0xff) ;
        if (PrintText) PrintText(Message) ;
    }
    return 1;
}

/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
DataFn_WriteOurInterfaceBlock             (char           *block,
                                           long            length)
{
  long*    data_ptr ;
  unsigned out_offset ;
  unsigned i ;

  data_ptr = (long*)block ;        /*-- DPUpdate works in longs! ------*/

  if (length != (data_ptr[1] + 8))
  {
    GtkWidget *errDialog = gtk_message_dialog_new (GTK_WINDOW(WinMain),
                              GTK_DIALOG_DESTROY_WITH_PARENT,
                              GTK_MESSAGE_ERROR,
                              GTK_BUTTONS_CLOSE,
                              "Internal error 1\n Logic Error");
    gtk_window_set_title (GTK_WINDOW(errDialog),
                              "Aardvark Embedded Solutions");
    gtk_window_set_icon_from_file (GTK_WINDOW(errDialog),
                              "MilanDiag-icon.png", NULL);
    gtk_dialog_run (GTK_DIALOG (errDialog));
    gtk_widget_destroy (errDialog);
    return;
  }
  out_offset = 0 ;

  /*-- OK we're now going to send the data - clear our overide error --*/
  /*-- First Lock the interface ---------------------------------------*/
  OutputArea->StartGuard++;

  /*-- Now copy the data ----------------------------------------------*/
  for (i = 0 ; i < ((length + 3) / sizeof (long)) ; ++i)
    OutputArea->TransferBlock[i + out_offset] = data_ptr[i];
  OutputArea->TransferSequence++;

  OutputArea->EndGuard = OutputArea->StartGuard;
}

/*---------------------------------------------------------------------------*\
 *
\*---------------------------------------------------------------------------*/
void
PrintTextHook                             (char           *line)
{
  DataFn_AddText(line, SysView, SysBuffer, 1, 0);
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void
DataFn_AddText                            (char           *line,
                                           GtkWidget      *view,
                                           GtkTextBuffer  *buff,
                                           char            scroll,
                                           char            reset)
{
  GtkTextIter    end_iter;
  GtkTextMark   *txt_mark;

  /*-- Ensure text has been given -------------------------------------*/
  if ((buff == NULL) || (view == NULL)) return;

  if (reset)
  { /*-- Set buffer as the text view ----------------------------------*/
    gtk_text_view_set_buffer        (GTK_TEXT_VIEW(view),  buff);
  }

  /*-- Locate end of text buffer --------------------------------------*/
  gtk_text_buffer_get_end_iter      (buff, &end_iter);

  /*-- Insert the required text ---------------------------------------*/
  gtk_text_buffer_insert            (buff, &end_iter, line, -1);

  if (scroll)
  { /*-- Set text mark at the end of the buffer -----------------------*/
    txt_mark = gtk_text_buffer_create_mark (buff, "TextBufferMark", &end_iter, TRUE);

    /*-- Ensure current line is shown on screen (scroll to bottom) ------*/
    gtk_text_view_scroll_mark_onscreen(GTK_TEXT_VIEW(view), txt_mark);
  }
  return;
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void
DataFn_AddComment                         (char         *comment)
{
  char buff[256];

  sprintf(buff, "\n   >>\n   >> %s\n   >>\n", comment);
  DataFn_AddText(buff, DiagView, DiagBuffer, 1, 0);
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void
DataFn_ClearDiagData                      (void)
{
  /*-- Ensure the dignostics tab is currently active ------------------*/
  if (gtk_notebook_get_current_page(GTK_NOTEBOOK(NoteMain)) == 0)
  { /*-- Clear data for the diagnostics tab ---------------------------*/
    DiagBuffer = gtk_text_buffer_new (NULL);
    DataFn_AddText((char*)"", DiagView, DiagBuffer, 1, 1);
  }
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
int
DataFn_CombineText                        (char         **buff)
{
  GtkTextIter  start;
  GtkTextIter  end;
  gchar       *tmp;

  /*-- Allocate buffer to store text within ---------------------------*/
  if (!(*buff = (char*)malloc (4194304 * sizeof(char)))) /* 4MB */
    return -1;

  /*-- Add all System Information to the buffer -----------------------*/
  strcpy(*buff, "\n-------------- SYSTEM INFORMATION ----------------\n\n");
  gtk_text_buffer_get_start_iter (SysBuffer, &start);
  gtk_text_buffer_get_end_iter   (SysBuffer, &end);
  tmp = g_strdup(gtk_text_buffer_get_text(SysBuffer, &start, &end, FALSE));
  if (tmp)
  { strcat(*buff, tmp);
    free  (tmp);
  }

  /*-- Add all Peripheral Information to the buffer -------------------*/
  strcat(*buff, "\n------------ PERIPHERAL INFORMATION --------------\n\n");
  gtk_text_buffer_get_start_iter (PerpBuffer, &start);
  gtk_text_buffer_get_end_iter   (PerpBuffer, &end);
  tmp = g_strdup(gtk_text_buffer_get_text(PerpBuffer, &start, &end, FALSE));
  if (tmp)
  { strcat(*buff, tmp);
    free  (tmp);
  }

  /*-- Add all Diagnostic Information to the buffer -------------------*/
  strcat(*buff, "\n------------ DIAGNOSTIC INFORMATION --------------\n\n");
  gtk_text_buffer_get_start_iter (DiagBuffer, &start);
  gtk_text_buffer_get_end_iter   (DiagBuffer, &end);
  tmp = g_strdup(gtk_text_buffer_get_text(DiagBuffer, &start, &end, FALSE));
  if (tmp)
  { strcat(*buff, tmp);
    free  (tmp);
  }
  return 0;
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void
DataFn_SendEmail                          (void)
{
  char    *buff = NULL;
  GError  *err  = NULL;

  /*-- Create text file with all required data ------------------------*/
  DataFn_CombineText(&buff);

  /*-- Write the data returned to the required file -------------------*/
  if (buff)
  { int fd = -1;

    /*-- Create the file ----------------------------------------------*/
    if ((fd = open("/tmp/diag.txt", O_RDWR|O_CREAT|O_TRUNC, 0666)) != -1)
    {
      /*-- Write data to the file -------------------------------------*/
      write (fd, buff, strlen(buff));
      close (fd);
    }

    /*-- Free the memory used by the buffer ---------------------------*/
    if (buff) free(buff);
  }

  /*-- Create an e-mail and attach the created file -------------------*/
  gnome_url_show ("mailto:support@aardvark.eu.com?subject=Automatic Mail"
                  "&attach=file:///tmp/diag.txt", &err);
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void
DataFn_CopyAll                            (void)
{
  GtkClipboard  *clip      = NULL;
  GtkTextBuffer *text_buff = NULL;
  GtkTextIter    start;
  GtkTextIter    end;
  gchar         *buff      = NULL;

  /*-- Determine which buffer is active -------------------------------*/
  switch (gtk_notebook_get_current_page(GTK_NOTEBOOK(NoteMain)))
  { case 0: text_buff = DiagBuffer; break;
    case 1: text_buff = PerpBuffer; break;
    case 2: text_buff = SysBuffer;  break;
  }

  /*-- Ensure a Text Buffer has been located --------------------------*/
  if (!text_buff) return;

  /*-- Add all information to the buffer ------------------------------*/
  gtk_text_buffer_get_start_iter (text_buff, &start);
  gtk_text_buffer_get_end_iter   (text_buff, &end);
  buff = g_strdup(gtk_text_buffer_get_text(text_buff, &start, &end, FALSE));
  if (!buff) return;

  /*-- Locate clipboard -----------------------------------------------*/
  if ((clip = gtk_clipboard_get (GDK_SELECTION_CLIPBOARD)))
  { /*-- Set the required text within the clipboard -------------------*/
    gtk_clipboard_set_text (clip, buff, -1);
  }
  free (buff);
  return;
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void
DataFn_Save                               (char           *filename)
{
  char    *buff = NULL;

  /*-- Create text file with all required data ------------------------*/
  DataFn_CombineText(&buff);

  /*-- Write the data returned to the required file -------------------*/
  if (buff)
  { int fd = -1;

    /*-- Create the file ----------------------------------------------*/
    if ((fd = open(filename, O_RDWR|O_CREAT|O_TRUNC, 0666)) != -1)
    {
      /*-- Write data to the file -------------------------------------*/
      write (fd, buff, strlen(buff));
      close (fd);
    }

    /*-- Free the memory used by the buffer ---------------------------*/
    if (buff) free(buff);
  }
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void
DataFn_Print                              (void)
{
  GtkWidget     *info_diag    = NULL;
  GtkTextBuffer *text_buff    = NULL;
  GtkTextIter    start;
  GtkTextIter    end;
  gchar         *buff         = NULL;
  FILE          *fp           = NULL;
  char           status[1024];

  /*-- Determine which buffer is active -------------------------------*/
  switch (gtk_notebook_get_current_page(GTK_NOTEBOOK(NoteMain)))
  { case 0: text_buff = DiagBuffer; break;
    case 1: text_buff = PerpBuffer; break;
    case 2: text_buff = SysBuffer;  break;
  }

  /*-- Ensure a Text Buffer has been located --------------------------*/
  if (!text_buff) return;

  /*-- Add all information to the buffer ------------------------------*/
  gtk_text_buffer_get_start_iter (text_buff, &start);
  gtk_text_buffer_get_end_iter   (text_buff, &end);
  buff = g_strdup(gtk_text_buffer_get_text(text_buff, &start, &end, FALSE));

  /*-- Write the data returned to temp file for printing --------------*/
  if (buff)
  { int fd = -1;

    /*-- Create the file ----------------------------------------------*/
    if ((fd = open("/tmp/MilanDiagPrint.txt", O_RDWR|O_CREAT|O_TRUNC, 0666)) != -1)
    {
      /*-- Write data to the file -------------------------------------*/
      write (fd, buff, strlen(buff));
      close (fd);
    }

    /*-- Free the memory used by the buffer ---------------------------*/
    if (buff) free(buff);

    /*-- Use popen call to handle the print out -----------------------*/
    if ((fp = popen ("lp /tmp/MilanDiagPrint.txt 2>/dev/null", "r")) != NULL)
    {
      /*-- Read data from the file ------------------------------------*/
      fgets (status, sizeof(status), fp);

      /*-- Display information dialog ---------------------------------*/
      info_diag = gtk_message_dialog_new (GTK_WINDOW(WinMain),
                              GTK_DIALOG_DESTROY_WITH_PARENT,
                              GTK_MESSAGE_INFO,
                              GTK_BUTTONS_CLOSE,
                              "Printing...:\n%s",
                              status);
      gtk_window_set_title (GTK_WINDOW(info_diag),
                              "Aardvark Embedded Solutions");
      gtk_window_set_icon_from_file (GTK_WINDOW(info_diag),
                              "MilanDiag-icon.png", NULL);
      gtk_dialog_run (GTK_DIALOG (info_diag));
      gtk_widget_destroy (info_diag);

      /*-- Close the file ---------------------------------------------*/
      pclose (fp);
    }
  }
  return;
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void
DataFn_PauseResume                        (GtkToggleButton *toggle)
{
  GtkWidget   *btn_reset  = lookup_widget(GTK_WIDGET(WinMain), "btn_reset");
  GtkWidget   *lbl_toggle = lookup_widget(GTK_WIDGET(WinMain), "lbl_pause_btn");
  GtkWidget   *img_toggle = lookup_widget(GTK_WIDGET(WinMain), "img_pause_btn");

  GtkTextIter  start;
  GtkTextIter  end;
  gchar       *tmp;

  if (DiagnosticsFrozen == FALSE)
  {
    /*-- Set diagnostics frozen flag ----------------------------------*/
    DiagnosticsFrozen        = TRUE;

    /*-- Change pause button to run -----------------------------------*/
    gtk_label_set_label (GTK_LABEL(lbl_toggle), "Run");
    gtk_image_set_from_stock (GTK_IMAGE(img_toggle), "gtk-media-play", GTK_ICON_SIZE_BUTTON);

    /*-- Disable the reset button -------------------------------------*/
    gtk_widget_set_sensitive (GTK_WIDGET(btn_reset), FALSE);

    /*-- Log that the capture is paused -------------------------------*/
    DataFn_AddText((char*)"\n\n******* Diagnostic Capture Paused ********\n", DiagView, DiagBuffer, 1, 0);

    /*-- Create a Pause Buffer ----------------------------------------*/
    PauseBuffer = gtk_text_buffer_new (NULL);
  }
  else
  {
    /*-- Clear diagnostics frozen flag --------------------------------*/
    DiagnosticsFrozen        = FALSE ;

    /*-- Change pause button to pause ---------------------------------*/
    gtk_label_set_label (GTK_LABEL(lbl_toggle), "Pause");
    gtk_image_set_from_stock (GTK_IMAGE(img_toggle), "gtk-media-pause", GTK_ICON_SIZE_BUTTON);

    /*-- Enable the reset button --------------------------------------*/
    gtk_widget_set_sensitive (GTK_WIDGET(btn_reset), TRUE);

    /*-- Add contents of Pause Buffer to the Diagnostics Buffer -------*/
    gtk_text_buffer_get_start_iter (PauseBuffer, &start);
    gtk_text_buffer_get_end_iter   (PauseBuffer, &end);
    tmp = g_strdup(gtk_text_buffer_get_text(PauseBuffer, &start, &end, FALSE));
    if (tmp)
    { DataFn_AddText(tmp, DiagView, DiagBuffer, 1, 0);
      free  (tmp);
    }
  }
  return;
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
int
DataFn_MainUpdater                        (gpointer          data)
{
  static u_int      current_index = 0;
  static int        char_index    = 0;
  static char       new_line      = FALSE;
  GtkTextBuffer    *text_buff     = (DiagnosticsFrozen)?PauseBuffer:DiagBuffer;
  char              scroll        = !DiagnosticsFrozen;
  char              line_buff[16384];

  if (!Going)
  {
    /*-- Waiting for a functional PCI card, Fill in system tab --------*/
    LineIndex = 0 ;

    /*-- Set system tag as being active -------------------------------*/
    gtk_notebook_set_current_page (GTK_NOTEBOOK(NoteMain), 2);

    /*-- Determine if we have acces to the device ---------------------*/
    DataFn_AddText((char*)"", SysView, SysBuffer, 0, 1);
    if (DataFn_CheckAccess(false, false))
    {
      /*-- Map device ram ---------------------------------------------*/
      MapDPRam() ;
      DiagOutputArea = BasicControl->DiagOutPointer ;

      if (MMFile && PC_INTERNAL_BLOCK(SharedMemoryBase)->DiagIndexMask != 0)
      { /*-- We can use the driver staging buffer ---------------------*/
        StageBuffer   =  PC_INTERNAL_BLOCK(SharedMemoryBase)->DiagBuffer ;
        StageMask     =  PC_INTERNAL_BLOCK(SharedMemoryBase)->DiagIndexMask ;
        StageIndexPtr = &PC_INTERNAL_BLOCK(SharedMemoryBase)->DiagWriteIndex ;
      }

      /*-- Remember we ARE running now --------------------------------*/
      Going = TRUE ;

      /*-- Set dignostics tab as being active -------------------------*/
      gtk_notebook_set_current_page   (GTK_NOTEBOOK(NoteMain), 0);

      /*-- Update peripherals tab now ---------------------------------*/
      DataFn_PerpUpdater (NULL);

      /*-- Set the peripherals timer going ----------------------------*/
      PerpTimerTag = g_timeout_add ( (guint) 5000, DataFn_PerpUpdater, NULL );

    }else
    { /*-- Lose any old lines -----------------------------------------*/
      SysBuffer  = gtk_text_buffer_new (NULL);
    }
    return TRUE;
  }

  /*-- Detect Completeing Restarts ------------------------------------*/
  if (Restarting && BasicControl->FlagWord == AARDVARK_FLAG_WORD)
  { /*-- This gets cleared by a restart! ------------------------------*/
    OutputArea->PCPresent = PCPresentFlag ;
    Restarting = false ;

    /*-- Lose any old lines -------------------------------------------*/
    SysBuffer  = gtk_text_buffer_new (NULL);

    /*-- Update system tab! -------------------------------------------*/
    DataFn_CheckAccess(false, false) ;
  }

  /*-- Grab lines for display -----------------------------------------*/
  while ((current_index & StageMask) != (*StageIndexPtr & StageMask))
  { char ch = StageBuffer[current_index++ & StageMask] ;

    if (ch == '\n' || ch == '\r' || ch == '\f')
    { DataFn_AddText(line_buff, DiagView, text_buff, scroll, 0);
      char_index              = 0;
      line_buff[char_index++] = '\n';
      new_line                = FALSE;
      if (ch == '\f')
        DataFn_AddText((char*)"\n\n", DiagView, text_buff, scroll, 0);
    }else
    { line_buff[char_index++] = ch;
      line_buff[char_index]   = 0;
    }
  }

  /*-- Now ensure that any partial line (such as the prompt) ----------*/
  /*-- are shown correctly! -------------------------------------------*/
  if (*line_buff && new_line)
  { DataFn_AddText(line_buff, DiagView, text_buff, scroll, 0);
    new_line = FALSE;
  }
  return TRUE;
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
int
DataFn_PerpUpdater                        (gpointer      data)
{
  char bit [256];
  char buff[256];

  if (!Going || BasicControl->FlagWord  != AARDVARK_FLAG_WORD)
    return TRUE;

  /*-- Clear data for the peripherals tab -----------------------------*/
  PerpBuffer = gtk_text_buffer_new (NULL);

  /*-- Determine dispensers on the system -----------------------------*/
  DataFn_AddText((char*)"Dispensers on the system are:\n", PerpView, PerpBuffer, 1, 1);

  DispenserBlock DispenserDetails ;
  char * DispenserName ;
  char Buffer[1024] ;
  int DispenserNo ;

  for (DispenserNo = 0 ; ReadDispenserDetails(DispenserNo,
                                                  &DispenserDetails) ; ++ DispenserNo)
  {
    switch(DispenserDetails.Unit)
      {
      case DP_AS_WH2:
          DispenserName = "Asahi Seiko Escalator" ;
          break ;

      case DP_AZK_HOPPER:
          DispenserName = "Azkoyen Hopper" ;
          break ;

      case DP_AZK_HOPPER_U:
          DispenserName = "Azkoyen Hopper U" ;
          break ;

      case DP_AZK_HOPPER_UPL:
          DispenserName = "Azkoyen Hopper U+" ;
          break ;

      case DP_CASHLESS_HUB:
          DispenserName = "Cashless Hub" ;
          break ;

      case DP_CC_CASSETTE:
          DispenserName = "Bill to Bill Cassette" ;
          break ;

      case DP_CDM_4000:
          DispenserName = "MFS CDM 4000 Cassette" ;
          break ;

      case DP_CLS_HOPPER:
          DispenserName =  "CLS Hopper" ;
          break ;

      case DP_CX25_TUBE:
          DispenserName = "Telequip CX25 Hopper" ;
          break ;

      case DP_EBDS_ROLL:
          DispenserName = "EBDS Recycler Roll" ;
          break ;

      case DP_FUJITSU_F400:
          DispenserName = "Fujitsu F4000" ;
          break ;

      case DP_FUJITSU_F53:
          DispenserName = "Fujitsu F53" ;
          break ;

      case DP_FUJITSU_F56:
          DispenserName = "Fujitsu F56" ;
          break ;

      case DP_ID003_BOX:
          DispenserName = "ID003 Recycler Note Box" ;
          break ;

      case DP_INNOV_NV11_RC:
         DispenserName = "NV11 Note Recycler" ;
         break ;

      case DP_INNOV_NV200_NOTE:
          DispenserName = "NV200 Denomination" ;
          break ;

      case DP_JCM_VEGA_RC:
          DispenserName = "JCM Vega Note" ;
          break ;

      case DP_MCL_BCR_HOPPER:
          DispenserName = "MCL BCR Hopper" ;
          break ;

      case DP_MCL_CR100_HOPPER:
          DispenserName = "MCL CR10x Hopper" ;
          break ;

      case DP_MCL_NR2_HOPPER:
          DispenserName = "MCL NR2 Hopper" ;
          break ;

      case DP_CC_GHOST_HOPPER:
          DispenserName = "Ghost (Coin count only)" ;
          break ;

      case DP_MCL_SCH2:
          DispenserName = "MCL Serial Compact Hopper 2" ;
          break ;

      case DP_MCL_SCH3:
          DispenserName = "MCL Serial Compact Hopper 3" ;
          break ;

      case DP_MCL_SCH3A:
          DispenserName = "MCL Combi Hopper" ;
          break ;

      case DP_MCL_SCH5:
          DispenserName = "MCL Compact Hopper 5 (DES)" ;
          break ;

      case DP_MCL_SUH1:
          DispenserName = "MCL Serial Universal Hopper" ;
          break ;

      case DP_MCL_SUH5:
         DispenserName = "MCL Universal Hopper 5 (DES)" ;
         break ;

      case DP_MEIBNR_LOADER:
         DispenserName = "Mars BNR Loader" ;
         break ;

      case DP_MEIBNR_RECYCLER:
         DispenserName = "Mars BNR Recycler" ;
         break ;

      case DP_MDB_LEVEL_2_TUBE:
          DispenserName = "MDB Tube" ;
          break ;

      case DP_MDB_TYPE_3_PAYOUT:
          DispenserName = "MDB Payout System" ;
          break ;

      case DP_MERKUR_100_PAY:
          DispenserName = "Merkur MD100 Roll" ;
          break ;

      case DP_NRI_CURRENZA_H2:
          DispenserName = "NRI Currenza H2" ;
          break ;

      case DP_SHOPPER:
          DispenserName = "Innovative SmartHopper" ;
          break ;

      case DP_SHOPPER_TOTAL:
         DispenserName = "Innovative Smart Hopper Summary" ;
         break ;

      case DP_TFLEX_TUBE:
         DispenserName = "Telequip TFlex Tube" ;
         break ;

      default:
          sprintf(Buffer, "Unknown code %08x", DispenserDetails.Unit) ;
          DispenserName = Buffer ;
          break ;
      }

    sprintf(buff, "    Dispenser %d: %s\n", DispenserNo, DispenserName) ;
    DataFn_AddText(buff, PerpView, PerpBuffer, 1, 0);

    sprintf(buff, "        Coin Value %ld, Number Paid %ld,",
                   DispenserDetails.Value, DispenserDetails.Count) ;
    DataFn_AddText(buff, PerpView, PerpBuffer, 1, 0);

    sprintf(buff, "        Inhibit %ld, Address %ld\n",
                   DispenserDetails.Inhibit, DispenserDetails.UnitAddress) ;
    DataFn_AddText(buff, PerpView, PerpBuffer, 1, 0);
  }

  DataFn_AddText((char*)"\nAcceptors on the system are:\n", PerpView, PerpBuffer, 1, 0);

  AcceptorBlock AcceptorDetails ;
  char * AcceptorName ;
  int AcceptorNo ;
  int CoinNo ;

  for (AcceptorNo = 0 ; ReadAcceptorDetails(AcceptorNo, &AcceptorDetails) ; ++ AcceptorNo)
  {
    switch(AcceptorDetails.Unit)
        {
        case DP_AST_GBA:
            AcceptorName = "AstroSystems GBA" ;
            break ;

        case DP_AZK_A6:
            AcceptorName = "Azkoyen A6" ;
            break ;

        case DP_AZK_MDB:
            AcceptorName = "Azkoyen MDB Changer" ;
            break ;

        case DP_AZK_X6:
            AcceptorName = "Azkoyen X6" ;
            break ;

        case DP_CC_ACCEPTOR:
            AcceptorName = "CashCode Acceptor" ;
            break ;

        case DP_CC_RECYCLER:
            AcceptorName = "Cashcode Recycler" ;
            break ;

        case DP_CLS:
            AcceptorName = "Crane PI CLS" ;
                break ;

        case DP_COINCO_BILLPRO:
            AcceptorName = "CoinCo BillPro" ;
            break ;

        case DP_COINCO_GLOBAL:
            AcceptorName = "CoinCo Global" ;
            break ;

        case DP_COINCO_MDB:
            AcceptorName = "CoinCo MDB Changer" ;
            break ;

        case DP_COINCO_MDB_BILL:
            AcceptorName = "CoinCo MDB Bill" ;
            break ;

        case DP_COINCO_VORTEX:
            AcceptorName = "CoinCo Vortex" ;
            break ;

        case DP_EBDS_NOTE:
            AcceptorName = "EBDS" ;
            break ;

        case DP_EBDS_RECYCLER:
            AcceptorName = "EBDS Recycler" ;
            break ;

        case DP_GPT_NOTE:
            AcceptorName = "GPT Argus" ;
            break ;

        case DP_ICT_U85:
            AcceptorName = "ICT U85" ;
            break ;

        case DP_ID003_NOTE:
            AcceptorName = "ID-003 Note" ;
            break ;

        case DP_ID003_RECYCLER:
            AcceptorName = "ID-003 Note Recycler" ;
            break ;

        case DP_INNOV_NV10:
            AcceptorName = "Innovative NV10" ;
            break ;

        case DP_INNOV_NV11:
            AcceptorName = "Innovative NV11" ;
            break ;

        case DP_INNOV_NV200:
            AcceptorName = "Innovative NV200" ;
            break ;

        case DP_INNOV_NV4:
            AcceptorName = "Innovative NV4" ;
            break ;

        case DP_INNOV_NV7:
            AcceptorName = "Innovative NV7" ;
            break ;

        case DP_INNOV_NV8:
            AcceptorName = "Innovative NV8" ;
            break ;

        case DP_INNOV_NV9:
            AcceptorName = "Innovative NV9" ;
            break ;

        case DP_JCM_CC_EBA:
            AcceptorName = "JCM EBA on cctalk" ;
            break ;

        case DP_JCM_CC_WBA:
            AcceptorName = "JCM WBA on cctalk" ;
            break ;

        case DP_JCM_NOTE:
            AcceptorName = "JCM Note" ;
            break ;

        case DP_JCM_VEGA:
            AcceptorName = "JCM Vega" ;
            break ;

        case DP_MARS_CASHFLOW_126:
            AcceptorName = "Mars Cashflow 126" ;
            break ;

        case DP_MARS_CASHFLOW_690:
            AcceptorName = "Mars Cashflow 690" ;
            break ;

        case DP_MARS_CASHFLOW_9500:
            AcceptorName = "Mars Cashflow 9500" ;
            break ;

        case DP_MARS_MDB:
            AcceptorName = "Mars MDB Changer" ;
            break ;

        case DP_MARS_SCR_ADVANCE:
            AcceptorName = "SCR Advance Recycler" ;
            break ;

        case DP_MARS_SC_ADVANCE:
            AcceptorName = "SC Advance" ;
            break ;
        case DP_MCL_7200:
            AcceptorName = "MCL 7200" ;
            break ;

        case DP_MCL_ARDAC:
            AcceptorName = "MCL Ardac /ID-003" ;
            break ;

        case DP_MCL_ARDAC_ELITE:
            AcceptorName = "MCL Ardac Elite" ;
            break ;

        case DP_MCL_BCR:
            AcceptorName = "MCL BCR Coin Recycler" ;
            break ;

        case DP_MCL_BCS:
            AcceptorName = "MCL Bulk coin Sorter" ;
            break ;

        case DP_MCL_CONDOR:
            AcceptorName = "MCL Condor" ;
            break ;

        case DP_MCL_CR100:
            AcceptorName = "MCL CR 10x Recycler" ;
            break ;

        case DP_MCL_LUMINA:
            AcceptorName = "MCL Lumina" ;
            break ;

        case DP_MCL_NR2:
            AcceptorName = "MCL NR2 recycler" ;
            break ;

        case DP_MCL_SR3:
            AcceptorName = "MCL SR3" ;
            break ;

        case DP_MCL_SR5:
            AcceptorName = "MCL SR5" ;
            break ;

        case DP_MCL_WACS:
            AcceptorName = "MCL Ardac / WACS" ;
            break ;

        case DP_MDB_BILL:
            AcceptorName = "MBD Bill" ;
            break ;

        case DP_MDB_LEVEL_2:
            AcceptorName = "MDB Level 2 Changer" ;
            break ;

        case DP_MDB_LEVEL_3:
            AcceptorName = "MDB Level 3 Changer" ;
            break ;

        case DP_MEIBNR:
            AcceptorName = "MEI BNR Recycler" ;
            break ;

        case DP_MERKUR_100:
            AcceptorName = "Merkur MD100 Recycler" ;
            break ;

        case DP_NRI_EAGLE:
            AcceptorName = "NRI Eagle" ;
            break ;

        case DP_NRI_G40:
            AcceptorName = "NRI G40" ;
            break ;

        case DP_NRI_PELICANO:
            AcceptorName = "NRI Pelicano" ;
            break ;

        case DP_SHOPPER_ACCEPT:
            AcceptorName = "SmartHopper Acceptor" ;
            break ;

        case DP_SSP_NOTE:
            AcceptorName = "SSP Acceptor" ;
            break ;

        case DP_SSP_RECYCLER:
            AcceptorName = "SSP Recycler" ;
            break ;

        case DP_CCTALK_INTERFACE | DP_COIN_ACCEPT_DEVICE:
            AcceptorName = "ccTalk Coin" ;
            break ;

        case DP_CCTALK_INTERFACE | DP_NOTE_ACCEPT_DEVICE:
            AcceptorName = "ccTalk Note" ;
            break ;

        default:
            sprintf(Buffer, "Unknown code %08x", AcceptorDetails.Unit) ;
            AcceptorName = Buffer ;
            break ;
        }


    sprintf(buff, "    Acceptor %d: %s, Default Path %ld,\n",
                   AcceptorNo, AcceptorName, AcceptorDetails.DefaultPath) ;
    DataFn_AddText(buff, PerpView, PerpBuffer, 1, 0);

    sprintf(buff, "       Event count %ld, Currency <%s>, %ld coins:\n",
                                                    AcceptorDetails.EventCount,
                                                    AcceptorDetails.Currency,
                                                    AcceptorDetails.NoOfCoins) ;
    DataFn_AddText(buff, PerpView, PerpBuffer, 1, 0);

    for (CoinNo = 0 ; CoinNo < AcceptorDetails.NoOfCoins ; ++CoinNo)
    {
      sprintf(buff, "          Coin %2d, Value %5ld, Count %4ld, Path %ld, Coins %4ld",
                     CoinNo,
                     AcceptorDetails.Coin[CoinNo].Value,
                     AcceptorDetails.Coin[CoinNo].Count,
                     AcceptorDetails.Coin[CoinNo].Path,
                     AcceptorDetails.Coin[CoinNo].PathCount) ;

      if (AcceptorDetails.Coin[CoinNo].DefaultPath)
      { sprintf(bit,", Default Path %dn", AcceptorDetails.Coin[CoinNo].DefaultPath);
        strcat(buff, bit);
      }else
        strcat(buff, "\n");
      DataFn_AddText(buff, PerpView, PerpBuffer, 1, 0);
    }
  }
  return TRUE;
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void
DataFn_Reset                              (void)
{
  GtkWidget *dialog = NULL;
  gint       retval = GTK_RESPONSE_REJECT;

  if (!Going || BasicControl->FlagWord  != AARDVARK_FLAG_WORD)
    return;

  dialog = gtk_message_dialog_new (GTK_WINDOW(WinMain),
                              GTK_DIALOG_DESTROY_WITH_PARENT,
                              GTK_MESSAGE_QUESTION,
                              GTK_BUTTONS_YES_NO,
                              "%s",
                              "Are you sure you want to reset the Milan Board");
  gtk_window_set_title (GTK_WINDOW(dialog), "Aardvark Embedded Solutions");
  gtk_window_set_icon_from_file (GTK_WINDOW(dialog), "MilanDiag-icon.png", NULL);
  retval = gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);

  if (retval != GTK_RESPONSE_YES)
    return;

  PCPresentFlag         = OutputArea->PCPresent;
  OutputArea->PCPresent = 1;

  /*-- We send the "Kill" command as a nul-terminated string ----------*/
  Block.Data[0] = 'k'  ;
  Block.Data[1] = '\0' ;
  Block.Length  = 2    ;

  DataFn_WriteOurInterfaceBlock((char*)&Block, 8 + Block.Length) ;
  /*-- Clear word in DP RAM to tell when PCI card comes back! ---------*/
  BasicControl->FlagWord = 0x12345678;
  Restarting = true;
  DataFn_AddText((char*)"\n\n ******* System Reset ********\n\n", DiagView, DiagBuffer, 1, 0);
  return;
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void
DataFn_Version                            (void)
{
  if (!Going || BasicControl->FlagWord  != AARDVARK_FLAG_WORD)
    return;

  PCPresentFlag = OutputArea->PCPresent ;
  OutputArea->PCPresent = 1 ;

  /*-- We send the "Version" command as a nul-terminated string -------*/
  Block.Data[0] = 'v'  ;
  Block.Data[1] = '\0' ;
  Block.Length  = 2    ;

  DataFn_WriteOurInterfaceBlock((char*)&Block, 8 + Block.Length) ;
  usleep(10000);
  OutputArea->PCPresent = PCPresentFlag ;
  return;
}

/*--------------------------------------------------------------------------*\
 *
\*--------------------------------------------------------------------------*/
void
DataFn_SendCommand                        (char        *cmd)
{
  if (!Going || BasicControl->FlagWord  != AARDVARK_FLAG_WORD)
    return;

  PCPresentFlag = OutputArea->PCPresent ;
  OutputArea->PCPresent = 1 ;

  /*-- We send the "Version" command as a nul-terminated string -------*/
  strcpy(Block.Data, cmd);
  Block.Length = strlen(cmd);

  DataFn_WriteOurInterfaceBlock((char*)&Block, 8 + Block.Length) ;
  usleep(10000);
  OutputArea->PCPresent = PCPresentFlag ;
  return;
}
