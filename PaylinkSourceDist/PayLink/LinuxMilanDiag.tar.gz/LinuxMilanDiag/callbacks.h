#include <gnome.h>


void
on_btn_pause_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_mail_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_comment_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_clear_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_copy_all_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_save_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_print_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_notebook1_switch_page               (GtkNotebook     *notebook,
                                        GtkNotebookPage *page,
                                        guint            page_num,
                                        gpointer         user_data);

void
on_txt_cmd_entry_activate              (GtkEntry        *entry,
                                        gpointer         user_data);

void
on_btn_version_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_reset_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_comment_ok_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_save_cancel_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_save_save_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_pause_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

gboolean
on_win_main_button_press_event         (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data);

gboolean
on_key_press_event                     (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data);

gboolean
on_key_release_event                   (GtkWidget       *widget,
                                        GdkEventKey     *event,
                                        gpointer         user_data);
